Badge Art sourced from SeanCantrell on DeviantArt

https://www.deviantart.com/seancantrell/art/All-Pokemon-Badges-399596702

Most badges are named to match the shows except for the ones in the 'misc' folder
I have taken the liberty of giving them names.
Visit here for more information about where they come from:
https://bulbapedia.bulbagarden.net/wiki/Badge#Gallery_of_unidentified_Badges